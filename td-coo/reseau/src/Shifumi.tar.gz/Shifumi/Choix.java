package Shifumi;

public enum Choix {
	PIERRE,FEUILLE,CISEAU,NONE;
}
